package com.springServer.ecom.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.springServer.ecom.Repository.OrderHistoryRepository;
import com.springServer.ecom.Services.CartService;
import com.springServer.ecom.Services.CurrentUserservice;
import com.springServer.ecom.modal.OrderHistory;

import java.security.Principal;
import java.util.List;

@CrossOrigin()
@RestController
@RequestMapping(value = "/history")
public class OrderHistoryController {

    @Autowired
    CartService cartService;
    @Autowired
    OrderHistoryRepository orderHistoryRepository;
    @Autowired
    CurrentUserservice currentUserservice;


    @Autowired
    public OrderHistoryController(CartService cartService, CurrentUserservice currentUserservice){
        this.cartService=cartService;
        this.currentUserservice=currentUserservice;
    }
    @RequestMapping(value = "/showorderhistory/recieve", method = RequestMethod.GET)
    @ResponseBody
    public List<OrderHistory> showorderhistory(Principal principal){
        return cartService.showorderHistory( currentUserservice.getUserid(principal),principal);
    }
}
